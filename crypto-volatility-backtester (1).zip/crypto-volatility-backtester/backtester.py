"""
Crypto Volatility & Trend Strategy Backtesting Engine
Author: Adem Yeşilkuş
Description: A modular backtesting framework simulating trend-following 
             strategies with dynamic volatility filters (ATR) and realistic execution costs.
"""

from typing import Dict, Tuple
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


class CryptoStrategyBacktester:

    def __init__(
        self,
        df: pd.DataFrame,
        initial_capital: float = 10000.0,
        commission: float = 0.0005,  # %0.05 Taker fee
        slippage: float = 0.0002,  # %0.02 Estimated slippage
    ):
        self.df = df.copy()
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage
        self.results: pd.DataFrame = pd.DataFrame()

    def add_indicators(self, ema_period: int = 50, atr_period: int = 14) -> None:
        """Hesaplamalara EMA ve Volatilite (ATR) göstergelerini ekler."""
        # Exponential Moving Average
        self.df['EMA'] = (
            self.df['close'].ewm(span=ema_period, adjust=False).mean()
        )

        # Average True Range (ATR)
        high_low = self.df['high'] - self.df['low']
        high_cp = np.abs(self.df['high'] - self.df['close'].shift())
        low_cp = np.abs(self.df['low'] - self.df['close'].shift())
        tr = pd.concat([high_low, high_cp, low_cp], axis=1).max(axis=1)
        self.df['ATR'] = tr.rolling(window=atr_period).mean()

    def generate_signals(self, atr_multiplier: float = 1.5) -> None:
        """Sinyal üretimi: Fiyat EMA üzerinde ve bant kırılımında LONG sinyali üretir."""
        self.df['Signal'] = 0

        # Condition: Fiyat EMA üstünde VE volatilite patlaması var
        long_condition = (self.df['close'] > self.df['EMA']) & (
            self.df['close'] > (self.df['open'] + self.df['ATR'] * atr_multiplier)
        )
        exit_condition = self.df['close'] < self.df['EMA']

        self.df.loc[long_condition, 'Signal'] = 1
        self.df.loc[exit_condition, 'Signal'] = 0

        # Pozisyon taşıma durumu (Forward fill)
        self.df['Position'] = self.df['Signal'].replace(to_replace=0, method='ffill').fillna(0)

    def run_backtest(self) -> Dict[str, float]:
        """Backtest simülasyonunu çalıştırır ve metrikleri hesaplar."""
        self.df['Market_Returns'] = self.df['close'].pct_change()

        # Pozisyon değişimlerini yakala (İşleme giriş/çıkış anları)
        self.df['Trades'] = self.df['Position'].diff().abs()

        # Maliyetler: Komisyon + Kayma
        execution_cost = self.df['Trades'] * (self.commission + self.slippage)

        # Strateji Getirisi
        self.df['Strategy_Returns'] = (
            self.df['Position'].shift(1) * self.df['Market_Returns']
        ) - execution_cost

        # Equity Curve (Sermaye Eğrisi)
        self.df['Equity'] = self.initial_capital * (
            1 + self.df['Strategy_Returns'].fillna(0)
        ).cumprod()

        return self._calculate_metrics()

    def _calculate_metrics(self) -> Dict[str, float]:
        """Risk ve getiri metriklerini hesaplayan iç fonksiyon."""
        total_return = (
            self.df['Equity'].iloc[-1] - self.initial_capital
        ) / self.initial_capital

        # Daily Returns & Volatility
        returns = self.df['Strategy_Returns'].dropna()
        sharpe_ratio = (
            (returns.mean() / returns.std()) * np.sqrt(365 * 24)
            if returns.std() != 0
            else 0.0
        )

        # Drawdown Hesaplama
        rolling_max = self.df['Equity'].cummax()
        drawdowns = (self.df['Equity'] - rolling_max) / rolling_max
        max_drawdown = drawdowns.min()

        # Profit Factor
        gains = returns[returns > 0].sum()
        losses = abs(returns[returns < 0].sum())
        profit_factor = gains / losses if losses != 0 else np.nan

        return {
            'Total Return (%)': round(total_return * 100, 2),
            'Sharpe Ratio': round(sharpe_ratio, 2),
            'Max Drawdown (%)': round(max_drawdown * 100, 2),
            'Profit Factor': round(profit_factor, 2) if profit_factor else 0.0,
            'Ending Capital ($)': round(self.df['Equity'].iloc[-1], 2),
        }


# --- SİMÜLASYON VE ÇALIŞTIRMA ---
if __name__ == '__main__':
    # Örnek Veri Üretimi (1000 saatlik synthetic OHLCV verisi)
    np.random.seed(42)
    dates = pd.date_range(start='2025-01-01', periods=1000, freq='1h')
    price_changes = np.random.normal(loc=0.0002, scale=0.01, size=1000)
    price = 50000 * np.exp(np.cumsum(price_changes))

    sample_data = pd.DataFrame(
        {
            'open': price,
            'high': price * (1 + np.abs(np.random.normal(0, 0.005, 1000))),
            'low': price * (1 - np.abs(np.random.normal(0, 0.005, 1000))),
            'close': price * (1 + np.random.normal(0, 0.003, 1000)),
            'volume': np.random.uniform(100, 1000, 1000),
        },
        index=dates,
    )

    # Motoru Başlat
    tester = CryptoStrategyBacktester(sample_data, initial_capital=10000)
    tester.add_indicators(ema_period=50, atr_period=14)
    tester.generate_signals(atr_multiplier=1.2)
    metrics = tester.run_backtest()

    print('=== BACKTEST PERFORMANS RAPORU ===')
    for metric, value in metrics.items():
        print(f'{metric}: {value}')
