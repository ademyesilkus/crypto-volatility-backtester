# Crypto Volatility & Trend Backtesting Engine (Python)

A vectorized Python backtesting engine built to evaluate volatility-filtered trend-following strategies on cryptocurrency OHLCV time series data.

## Features
- **Data Processing:** Native integration with `pandas` and `numpy` for vectorized performance calculations.
- **Dynamic Volatility Filter:** Incorporates Average True Range (ATR) breakouts to avoid false signals during range-bound regimes.
- **Realistic Execution Simulation:** Accounts for exchange trading commissions (e.g., Binance Taker fees) and order execution slippage.
- **Institutional Metrics:** Automatically outputs Sharpe Ratio, Max Drawdown (MDD), Profit Factor, and Cumulative Equity Growth.

## Quick Start

```bash
git clone https://github.com/ademyesilkus/crypto-volatility-backtester.git
cd crypto-volatility-backtester
pip install -r requirements.txt
python backtester.py
```
